// HelloWorld.cpp : Defines the entry point for the console application.
//

#include <iostream>

int main()
{
	std::cout << "Hello, World!" << std::endl;
	return 0;
}

