// Types.cpp : Defines the entry point for the console application.
//

int main()
{
	int i{ 2 };
	i = 3.2;
	i = 2.9;
	i = -1;

	unsigned int u{ 0 };
	u = -2;

	double d{ 2.7 };
	i = d;
	d = i;

	bool flag{ true };
	flag = false;
	flag = 7;



	return 0;
}

