
int AddTwo(int i)
{
	return i + 2;
}