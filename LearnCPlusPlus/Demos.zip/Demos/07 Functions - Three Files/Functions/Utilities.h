int AddTwo(int i);
