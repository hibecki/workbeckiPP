#pragma once
class Rectangle
{
public:

	int _width;
	int _height;
};
