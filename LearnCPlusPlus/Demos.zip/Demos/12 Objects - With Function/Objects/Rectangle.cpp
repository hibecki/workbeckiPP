#include "Rectangle.h"

//int Rectangle::area()
//{
//	return _width * _height;
//}
