#pragma once
class Rectangle
{
public:

	int _width;
	int _height;

	//int area();
	int area()
	{
		return _width * _height;
	}


};
