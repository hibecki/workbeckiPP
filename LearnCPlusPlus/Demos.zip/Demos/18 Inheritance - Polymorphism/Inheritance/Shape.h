#pragma once
class Shape
{
public:
	virtual int area() const = 0;
};

