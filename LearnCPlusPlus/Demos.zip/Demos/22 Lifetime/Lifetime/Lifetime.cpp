// Lifetime.cpp : Defines the entry point for the console application.
//

#include "Squawker.h"
#include "Functions.h"

int main()
{
	Squawker noname;
	Squawker Kate("Kate");

	allocate();
	return 0;
}

