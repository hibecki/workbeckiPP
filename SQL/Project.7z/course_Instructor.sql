/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: course_instructor                                     */
/*==============================================================*/
create table course_instructor (
   instructor_code      varchar(30)          not null,
   course_code          varchar(30)          not null,
   confirm_date         datetime             null,
   ref_doc              varchar(30)          null,
   instructor_cost      money                null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   constraint pk_course_instructor primary key (instructor_code, course_code)
)
go

