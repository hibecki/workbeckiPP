/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: ini_config                                            */
/*==============================================================*/
create table ini_config (
   client_code          varchar(30)          not null,
   system               nvarchar(50)         not null,
   module               nvarchar(50)         not null,
   cnfig_item           nvarchar(50)         not null,
   text_value           nvarchar(500)        not null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   numeric              identity,
   rowversion           timestamp            null,
   constraint pk_ini_config primary key (client_code, system, module, cnfig_item)
)
go

