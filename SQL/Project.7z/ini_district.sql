/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: ini_district                                          */
/*==============================================================*/
create table ini_district (
   country_code         int                  not null,
   province_code        char(8)              not null,
   district_code        char(8)              not null,
   district_desc        nvarchar(100)        not null,
   area_part            varchar(30)          null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_ini_district primary key (district_code, province_code, country_code)
)
go

