/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: ini_list_zip                                          */
/*==============================================================*/
create table ini_list_zip (
   country_code         int                  not null,
   province_code        char(8)              not null,
   district_code        char(8)              not null,
   subistrict_code      char(8)              not null,
   zip_code             char(5)              not null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_ini_list_zip primary key (province_code, country_code, district_code, subistrict_code, zip_code)
)
go

