/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: mem_education                                         */
/*==============================================================*/
create table mem_education (
   member_code          varchar(30)          not null,
   rec_no               int                  not null,
   degree               nvarchar(100)        not null,
   colledge_name        nvarchar(500)        null,
   faculty              nvarchar(500)        null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_mem_education primary key (rec_no, member_code)
)
go

