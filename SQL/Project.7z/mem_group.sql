/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: mem_group                                             */
/*==============================================================*/
create table mem_group (
   mem_group_code       char(3)              not null,
   mem_group_desc       nvarchar(100)        not null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_mem_group primary key (mem_group_code)
)
go

