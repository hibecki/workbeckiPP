/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: mem_health                                            */
/*==============================================================*/
create table mem_health (
   member_code          varchar(30)          not null,
   medical_history      nvarchar(500)        null,
   blood_group          char(1)              null,
   hobby                nvarchar(500)        null,
   restrict_food        nvarchar(500)        null,
   special_skill        nvarchar(500)        null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_mem_health primary key (member_code)
)
go

