/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: mem_product                                           */
/*==============================================================*/
create table mem_product (
   member_code          varchar(30)          not null,
   product_code         varchar(30)          not null,
   grow_area            decimal(7,2)         null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_mem_product primary key (product_code, member_code)
)
go

