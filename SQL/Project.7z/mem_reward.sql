/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: mem_reward                                            */
/*==============================================================*/
create table mem_reward (
   member_code          varchar(30)          not null,
   rec_no               int                  not null,
   reward_desc          nvarchar(100)        not null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_mem_reward primary key (rec_no, member_code)
)
go

