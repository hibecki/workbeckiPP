/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: mem_site_visit                                        */
/*==============================================================*/
create table mem_site_visit (
   member_code          varchar(30)          not null,
   rec_no               int                  not null,
   site_visit_desc      nvarchar(500)        not null,
   country_code         int                  null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_mem_site_visit primary key (rec_no, member_code)
)
go

