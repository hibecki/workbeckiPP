/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: mem_status                                            */
/*==============================================================*/
create table mem_status (
   mstatus_code         char(3)              not null,
   mstatus_desc         nvarchar(100)        not null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_mem_status primary key (mstatus_code)
)
go

