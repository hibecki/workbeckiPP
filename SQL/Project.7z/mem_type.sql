/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: mem_type                                              */
/*==============================================================*/
create table mem_type (
   mem_group_code       char(3)              not null,
   mem_type_code        char(3)              not null,
   mem_type_desc        nvarchar(100)        not null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_mem_type primary key (mem_type_code, mem_group_code)
)
go

