/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: mem_worklist                                          */
/*==============================================================*/
create table mem_worklist (
   rec_no               int                  not null,
   member_code          varchar(30)          null,
   company_name_th      nvarchar(100)        null,
   company_name_eng     nvarchar(100)        null,
   position_name_th     nvarchar(100)        null,
   position_name_eng    nvarchar(100)        null,
   work_year            char(4)              null,
   office_address       nvarchar(500)        null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_mem_worklist primary key (rec_no)
)
go

