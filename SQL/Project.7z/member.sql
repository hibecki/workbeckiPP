/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: member                                                */
/*==============================================================*/
create table member (
   member_code          varchar(30)          not null,
   fname                nvarchar(100)        null,
   lname                nvarchar(100)        null,
   sex                  char(1)              null,
   nationality          nvarchar(30)         null,
   mem_photo            varchar(30)          null,
   cid_type             char(1)              null,
   cid_card             varchar(30)          null,
   cid_card_pic         varchar(30)          null,
   birthdate            datetime             null,
   current_age          smallint             null,
   religion             nvarchar(30)         null,
   place_name           varchar(50)          null,
   marry_status         char(1)              null,
   h_no                 varchar(20)          null,
   lot_no               varchar(20)          null,
   village              nvarchar(50)         null,
   building             nvarchar(50)         null,
   floor                varchar(20)          null,
   room                 varchar(20)          null,
   lane                 nvarchar(50)         null,
   street               nvarchar(50)         null,
   subistrict_code      char(8)              null,
   district_code        char(8)              null,
   province_code        char(8)              null,
   country_code         int                  null,
   zip_code             char(5)              null,
   mstatus_code         char(3)              null,
   mem_type_code        char(3)              null,
   mem_group_code       char(3)              null,
   mlevel_code          char(3)              null,
   zone                 varchar(30)          null,
   latitude             decimal(9,6)         null,
   longitude            dec(9,6)             null,
   texta_address        varchar(200)         null,
   textb_address        varchar(200)         null,
   textc_address        varchar(200)         null,
   tel                  nvarchar(50)         null,
   mobile               nvarchar(50)         null,
   fax                  nvarchar(50)         null,
   social_app_data      nvarchar(500)        null,
   email                nvarchar(100)        null,
   parent_code          varchar(30)          null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_member primary key (member_code)
)
go

