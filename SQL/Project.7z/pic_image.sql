/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: pic_image                                             */
/*==============================================================*/
create table pic_image (
   image_code           varchar(30)          not null,
   image_name           nvarchar(50)         null,
   ref_doc_type         varchar(30)          null,
   ref_doc_code         varchar(30)          null,
   image_file           text                 null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   constraint pk_pic_image primary key (image_code)
)
go

