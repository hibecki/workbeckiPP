/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: product_type                                          */
/*==============================================================*/
create table product_type (
   product_group_code   varchar(30)          not null,
   product_type_code    varchar(30)          not null,
   product_type_desc    nvarchar(100)        not null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   rowversion           timestamp            null,
   constraint pk_product_type primary key (product_type_code, product_group_code)
)
go

