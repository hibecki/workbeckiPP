/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: project_course                                        */
/*==============================================================*/
create table project_course (
   course_code          varchar(30)          not null,
   project_code         varchar(30)          null,
   ctype_code           varchar(30)          null,
   cgroup_code          varchar(30)          null,
   course_desc          nvarchar(100)        not null,
   course_date          datetime             null,
   course_approve_date  datetime             null,
   course_begin         datetime             null,
   course_end           datetime             null,
   ref_doc              varchar(30)          null,
   budget               money                null,
   charge_head          money                null,
   support_head         money                null,
   project_manager      nvarchar(100)        null,
   target_member_join   int                  null,
   active_member_join   int                  null,
   passed_member        int                  null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   constraint pk_project_course primary key (course_code)
)
go

