/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: project_daily_checklist                               */
/*==============================================================*/
create table project_daily_checklist (
   course_code          varchar(30)          not null,
   member_code          varchar(30)          not null,
   course_date          datetime             not null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   constraint pk_project_daily_checklist primary key (course_date, course_code, member_code)
)
go

