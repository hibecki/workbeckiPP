/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     7/1/2016 2:43:24 PM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: train_place                                           */
/*==============================================================*/
create table train_place (
   place_code           varchar(30)          not null,
   instructor_desc      nvarchar(100)        not null,
   confirm_date         datetime             null,
   ref_doc              varchar(30)          null,
   contactor            nvarchar(100)        null,
   contactor_detail     nvarchar(500)        null,
   x_status             char(1)              null,
   x_note               nvarchar(50)         null,
   x_log                nvarchar(500)        null,
   id                   binary(99)           not null,
   constraint pk_train_place primary key (place_code)
)
go

